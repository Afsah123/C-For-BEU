﻿namespace viewmodeltask.Models
{
    public class StudentPersonal
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string Surname { get; set; }
        public string Gender { get; set; }
        public string Address { get; set; }
        public int Age { get; set; }
        public ICollection<StudentUniversity> UniversityDetails { get; set; }
    }

}
