﻿namespace viewmodeltask.Models
{
    public class StudentUniversity
    {
        public int Id { get; set; }
        public int StudentId { get; set; }
        public string Subjects { get; set; }
        public string Marks { get; set; }

        public StudentPersonal StudentPersonal { get; set; }
    }

}
