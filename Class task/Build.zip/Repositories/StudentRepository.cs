﻿using viewmodeltask.Models;
using viewmodeltask.ViewModels;

namespace viewmodeltask.Repositories
{
    public class StudentRepository : IStudentRepository
    {
        private List<StudentPersonal> personalData = new List<StudentPersonal>
    {
        new StudentPersonal { Id = 1, Name = "Samad", Surname = "Alakbarov", Gender = "Male", Address = "test address", Age = 20 },
        new StudentPersonal { Id = 2, Name = "Mirali", Surname = "Abdullayev", Gender = "Male", Address = "test address2", Age = 19 }
    };

        private List<StudentUniversity> universityData = new List<StudentUniversity>
    {
        new StudentUniversity { Id = 1, StudentId = 1, Subjects = "Test1, Test2", Marks = "90, 85" },
        new StudentUniversity { Id = 2, StudentId = 2, Subjects = "Test2, Test1", Marks = "88, 88" }
    };

        public List<StudentViewModel> GetAllStudents()
        {
            var students = from personal in personalData
                           join university in universityData
                           on personal.Id equals university.StudentId
                           select new StudentViewModel
                           {
                               PersonalInfo = personal,
                               UniversityInfo = university
                           };

            return students.ToList();
        }
    }
}
