﻿using Microsoft.AspNetCore.Mvc;
using viewmodeltask.Models;
using viewmodeltask.Repositories;
using viewmodeltask.ViewModels;

namespace viewmodeltask.Controllers
{
    public class StudentController : Controller
    {
        private readonly IStudentRepository _studentRepository;

        public StudentController()
        {
            _studentRepository = new StudentRepository();
        }

        public IActionResult Index()
        {
            List<StudentViewModel> students = _studentRepository.GetAllStudents();
            return View(students);
        }
    }
}
