﻿using viewmodeltask.Models;

namespace viewmodeltask.ViewModels
{
    public class StudentViewModel
    {
        public StudentPersonal PersonalInfo { get; set; }
        public StudentUniversity UniversityInfo { get; set; }
    }
}
